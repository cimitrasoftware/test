<!DOCTYPE HTML>
<html lang="en">

<head>
	<title>Your Insecure Bank</title>
	<meta charset="utf-8">
	<meta name="author" content="Jim Eddy">
	<meta name="description" content="Cybersecurity Demo">
	<link rel="stylesheet" type="text/css" media="screen" href="style.css" /> 
</head>

<body>

<?php

//Display title
echo "<h1>Your Insecure Bank</h1>";
echo "<h2>Personal Banking Made Easy!</h2>";
echo "<hr><br>";

?>

<!-- **** BEGIN FORM **** -->
<!-- note: form action should be post instead of get! -->
<form action="accounts.php" method="GET" id='inputForm'>
	<fieldset>
		<legend>Secure Login</legend>
		<label for="name">Username:</label><input type='text' id="name" name='name' required form='inputForm'>	
		<label for="name">Password:</label><input type='password' id="password" name='password' required form='inputForm'>
		<input type="submit" id="submit1" name = 'Submit' value = 'Submit'>
	</fieldset>
</form>

<!-- **** END OF FORM **** -->

<?php

//footer with copyright symbol and php displaying the current year
echo "<footer>&copy; Jim Eddy - ".date("Y")."</footer>";

?>

</body>
</html>
