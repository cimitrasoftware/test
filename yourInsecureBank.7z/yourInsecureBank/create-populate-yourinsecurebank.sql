-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Oct 01, 2016 at 03:03 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yourinsecurebank`
--
CREATE DATABASE IF NOT EXISTS `yourinsecurebank` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `yourinsecurebank`;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `ID` int(11) NOT NULL,
  `CustomerID` int(10) NOT NULL,
  `date` date NOT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `debit` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `credit` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `balance` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`ID`, `CustomerID`, `date`, `type`, `description`, `debit`, `credit`, `balance`) VALUES
(1, 100, '2016-08-04', 'Debit', 'Maplefields', '$25.00', NULL, '$1500.00'),
(2, 201, '2016-04-10', 'Debit', 'ABC Lunch Shop', '$5.00', NULL, '$1200.00'),
(3, 201, '2016-04-10', 'Credit', 'Deposit - Paycheck', NULL, '$1000.00', '$2200.00'),
(4, 201, '2016-04-11', 'Debit', 'Best Buy', '$50.00', NULL, '$2150.00'),
(5, 201, '2016-04-11', 'Debit', 'Lunches2Go', '$10.00', NULL, '$2140.00'),
(6, 201, '2016-04-11', 'Debit', 'Staples', '$40.00', NULL, '$2100.00'),
(7, 201, '2016-04-14', 'Debit', 'Maplefields', '$5.00', NULL, '$2095.00'),
(8, 202, '2016-04-02', 'Debit', 'Amazon', '$200.00', NULL, '$5400.00'),
(9, 202, '2016-04-04', 'Debit', 'eBay', '$50.00', NULL, '$5350.00'),
(10, 202, '2016-04-04', 'Debit', 'B&H Photo Video', '$300.00', NULL, '$5050.00'),
(11, 202, '2016-04-06', 'Debit', 'Coffee Shop', '$10.00', NULL, '$5040.00'),
(12, 202, '2016-04-10', 'Debit', 'Verizon', '$100.00', NULL, '$4940.00'),
(13, 202, '2016-04-02', 'Credit', 'Deposit - Paycheck', NULL, '$2200.00', '$7140.00'),
(14, 203, '2016-04-07', 'Debit', 'Panera Bread', '$10.00', NULL, '$450.00'),
(15, 203, '2016-04-10', 'Credit', 'Deposit - check', NULL, '$300.00', '$750.00'),
(16, 203, '2016-04-12', 'Debit', 'ATM Withdrawal', '$50.00', NULL, '$700.00'),
(17, 203, '2016-04-12', 'Debit', 'Subway', '$15.00', NULL, '$685.00'),
(18, 203, '2016-04-10', 'Credit', 'Deposit - check', NULL, '$200.00', '$885.00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `CustomerID` int(11) NOT NULL,
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`CustomerID`, `username`, `password`) VALUES
(100, 'test', 'test'),
(201, 'johndoe', '12345'),
(202, 'janesmith', 'password'),
(203, 'bobsmith', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `users_pw_hashed`
--

CREATE TABLE `users_pw_hashed` (
  `CustomerID` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users_pw_hashed`
--

INSERT INTO `users_pw_hashed` (`CustomerID`, `username`, `password`) VALUES
(100, 'test', '098f6bcd4621d373cade4e832627b4f6'),
(201, 'johndoe', '827ccb0eea8a706c4c34a16891f84e7b'),
(202, 'janesmith', '5f4dcc3b5aa765d61d8327deb882cf99'),
(203, 'bobsmith', '3a3a5c3f10e14cc9d5e92127a0ee0880');

-- --------------------------------------------------------

--
-- Table structure for table `users_pw_hashed_salt`
--

CREATE TABLE `users_pw_hashed_salt` (
  `CustomerID` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users_pw_hashed_salt`
--

INSERT INTO `users_pw_hashed_salt` (`CustomerID`, `username`, `password`, `salt`) VALUES
(100, 'test', '098f6bcd4621d373cade4e832627b4f6', '51b6e225b30508aede8d7763cbc83a1a'),
(201, 'johndoe', '827ccb0eea8a706c4c34a16891f84e7b', 'b3f952d5d9adea6f63bee9d4c6fceeaa'),
(202, 'janesmith', '5f4dcc3b5aa765d61d8327deb882cf99', 'ccf6184efe5e38da61ef2e9a30d1c1ea'),
(203, 'bobsmith', '3a3a5c3f10e14cc9d5e92127a0ee0880', '69e1f252521b46b2facc8615f97e0362');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`CustomerID`);

--
-- Indexes for table `users_pw_hashed`
--
ALTER TABLE `users_pw_hashed`
  ADD PRIMARY KEY (`CustomerID`);

--
-- Indexes for table `users_pw_hashed_salt`
--
ALTER TABLE `users_pw_hashed_salt`
  ADD PRIMARY KEY (`CustomerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
