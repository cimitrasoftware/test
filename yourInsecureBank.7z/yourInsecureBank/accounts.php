<!DOCTYPE HTML>
<html lang="en">

<head>
	<title>Your Insecure Bank</title>
	<meta charset="utf-8">
	<meta name="author" content="Jim Eddy">
	<meta name="description" content="Cybersecurity Demo">
	<link rel="stylesheet" type="text/css" media="screen" href="style.css" /> 
</head>

<body>

<?php

//Display title
echo "<h1>Your Insecure Bank</h1>";
echo "<h2>Personal Banking Made Easy!</h2>";

//set to 'TRUE' if you want to see the GET array values
$debug = FALSE;

if($debug == TRUE){
	print "<p>GET array from form input:<pre>"; print_r($_GET); print "</pre></p>";
}

echo "<hr><br>";
?>

<?php

//connect to database to authenticate if it was submitted from the form
if (isset($_GET['Submit'])){

	$user_input = $_GET['name'];
	$user_pass = $_GET['password'];
	
	//note: these database credentials should not be stored here!
	$user = 'cyber';
	$password = 'security';
	$db = 'yourinsecurebank';
	$tb = 'users';
	$host = 'localhost';
	$port = 80;
	
	$transactionDisplay = FALSE;
	$userList = array();
	$link = mysqli_connect($host, $user, $password, $db);
	
	if (mysqli_connect_errno()) {
		    printf("Connect failed: %s\n", mysqli_connect_error());
		    exit();
	}
		
	//SQL query to authenticate user name and password from form input
	$query = "Select * FROM ".$tb." WHERE username = '".$user_input."' AND password ='".$user_pass."';";
		
	$result = mysqli_query($link, $query) or die(mysqli_error($link));
	
	if (mysqli_num_rows($result) > 0) {
	// output data of each row
		while($row = mysqli_fetch_assoc($result)) {
		 
		echo "<h2>Welcome back ".$row['username']."!</h2>";
		echo "<p id='customerID'>Customer ID: ".$row['CustomerID']."</p>";
		$userList[] = $row['CustomerID'];
		$transactionDisplay = TRUE;
		}
	}

	if($transactionDisplay == FALSE){
		echo "Unrecognized username and/or password.";
	}

	mysqli_free_result($result);

	/* close connection */
	mysqli_close($link);
	mysqli_free_result($result);

	if($transactionDisplay == TRUE){
		//note: these database credentials should not be stored here!
		$user = 'cyber';
		$password = 'security';
		$db = 'yourinsecurebank';
		$tb = 'transactions';
		$host = 'localhost';
		$port = 80;
		
		//display the records in a table
		echo "<hr>";
		echo "<h3>Transactions:</h3>";
		echo "<table>";
		
		//display table headers
		echo "<tr>
				<th>Customer ID</th>
				<th>DATE</th>
				<th>TYPE</th>
				<th class='small'>DESCRIPTION</th>
				<th>DEBIT</th>
				<th class='small'>CREDIT</th>
				<th class='small'>BALANCE</th>
			</tr>";

		if (mysqli_connect_errno()) {
			    printf("Connect failed: %s\n", mysqli_connect_error());
			    exit();
		}

		$link = mysqli_connect($host, $user, $password, $db);
		$query = "Select * FROM ".$tb.";";
		
		$result = mysqli_query($link, $query) or die(mysqli_error($link));
		
		if (mysqli_num_rows($result) > 0) {
		// output data of each row
			while($row = mysqli_fetch_assoc($result)) {
				
				if(in_array($row['CustomerID'], $userList)){
					echo "<tr>"
							."<td>".$row['CustomerID']."</td>"
							."<td>".$row['date']."</td>"
							."<td class='small left'>".$row['type']."</td>"
							."<td class='left'>" .$row['description']. "</td>"
							."<td class='small right'>".$row['debit']."</td>"
							."<td class='small right'>".$row['credit']."</td>"
							."<td class='small right'>".$row['balance']."</td>"
						."</tr>";
				}
			}
		}
		mysqli_free_result($result);
		/* close connection */
		mysqli_close($link);
		echo "</table>";
//end transaction display	
	}
//end isset
}

//footer with copyright symbol and php displaying the current year
echo "<footer>&copy; Jim Eddy - ".date("Y")."</footer>";

?>

</body>
</html>
